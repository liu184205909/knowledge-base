<section class="ew-t17-ui" data-t17-ui>
  <div class="ew-t17-ui__notice" data-notice aria-live="polite"></div>
  <p class="ew-t17-ui__fixture-note" data-fixture-note hidden>Development fixture — local visual references and test prices only. Not for sale.</p>
  <section class="ew-t17-ui__intro" aria-labelledby="ew-t17-studio-title">
    <span class="ew-t17-ui__eyebrow">CUSTOM BRACELET STUDIO</span><h1 id="ew-t17-studio-title">Build your bracelet, bead by bead.</h1><p>Mix independent sizes freely. Every selected Variant keeps its own scale, price and placement.</p>
  </section>
  <div class="ew-t17-ui__workspace">
    <section class="ew-t17-ui__stage" aria-label="Bracelet design canvas">
      <div class="ew-t17-ui__stage-head"><div><span class="ew-t17-ui__eyebrow">YOUR DESIGN</span><strong data-fit>Start with a material</strong></div><div class="ew-t17-ui__mobile-stats" aria-label="Current design measurements"><span><small>Length</small><b data-mobile-length>0 mm</b></span><span><small>Pieces</small><b data-mobile-pieces>0</b></span><span><small>Suggested wrist</small><b data-mobile-fit-range>—</b></span></div></div>
      <div class="ew-t17-ui__canvas" data-canvas>
        <img class="ew-t17-ui__tray" data-tray alt="Bracelet design tray">
        <div class="ew-t17-ui__ring" data-ring></div>
        <p class="ew-t17-ui__empty" data-empty>Choose a material to begin your bracelet.</p>
        <button class="ew-t17-ui__undo" type="button" data-action="undo" aria-label="Undo last edit" title="Undo last edit" disabled><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8.5 8 4.5 12l4 4"></path><path d="M5 12h8.5a5 5 0 1 1-4.3 7.5"></path></svg></button>
      </div>
      <div class="ew-t17-ui__stage-actions" data-stage-actions aria-label="Design actions">
        <button class="ew-t17-ui__stage-wrist" type="button" data-action="wrist" aria-label="Set wrist measurement" title="Set wrist measurement"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8.5h16v7H4z"></path><path d="M7 8.5v3M10 8.5v2M13 8.5v3M16 8.5v2"></path></svg><span data-wrist-action>Set wrist</span></button>
        <button type="button" data-action="background" aria-label="Change tray background" title="Change tray background"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v14H4z"></path><circle cx="9" cy="10" r="1.5"></circle><path d="m5 17 5-5 3 3 2-2 4 4"></path></svg></button>
        <button type="button" data-action="reset" aria-label="Clear design" title="Clear design"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14"></path><path d="M10 11v6M14 11v6"></path><path d="M8 7l1-3h6l1 3"></path><path d="M7 7l1 13h8l1-13"></path></svg></button>
        <button type="button" data-action="save" aria-label="Save design" title="Save design"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h12l3 3v13H5z"></path><path d="M8 4v6h8V4"></path><path d="M8 20v-6h8v6"></path></svg></button>
        <button class="is-assemble" type="button" data-action="assemble" aria-label="Assemble bracelet" title="Assemble bracelet"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="5" r="2"></circle><circle cx="18" cy="9" r="2"></circle><circle cx="18" cy="15" r="2"></circle><circle cx="12" cy="19" r="2"></circle><circle cx="6" cy="15" r="2"></circle><circle cx="6" cy="9" r="2"></circle></svg><span class="ew-t17-ui__assemble-label" data-assemble-label>Assemble</span></button>
      </div>
      <section class="ew-t17-ui__sequence-panel" aria-label="Order and details"><button class="ew-t17-ui__sequence-toggle" type="button" data-action="toggle-sequence" aria-expanded="false"><span>Order &amp; details</span><b data-sequence-count>0 pieces</b><i aria-hidden="true">⌄</i></button><div class="ew-t17-ui__sequence" data-sequence hidden></div></section>
      <div class="ew-t17-ui__metrics"><span><small>Length</small><b data-length>0 mm</b></span><span><small>Pieces</small><b data-pieces>0</b></span><span class="ew-t17-ui__suggested-wrist"><small>Suggested wrist</small><b data-fit-range>—</b></span><span class="ew-t17-ui__total"><small>Design total</small><b data-total>$0.00</b></span></div>
      <div class="ew-t17-ui__actions"><button type="button" data-action="save">Save draft</button><button class="is-primary" type="button" data-action="finish">Finish design <span aria-hidden="true">→</span></button></div>
    </section>
    <section class="ew-t17-ui__catalog" aria-label="Materials">
      <div class="ew-t17-ui__catalog-title"><div><span class="ew-t17-ui__eyebrow">MATERIAL LIBRARY</span><h2>Choose a Variant</h2></div></div>
      <div class="ew-t17-ui__tabs" role="tablist"><button class="is-active" type="button" data-type="crystal">Crystals</button><button type="button" data-type="accessory">Accessories</button><button class="ew-t17-ui__search-toggle" type="button" aria-label="Search materials" title="Search materials" data-action="search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"></circle><path d="m16 16 4.25 4.25"></path></svg></button></div>
      <input class="ew-t17-ui__search" type="search" data-search placeholder="Search materials" aria-label="Search materials">
      <div class="ew-t17-ui__library-body"><aside class="ew-t17-ui__filter-panel"><div class="ew-t17-ui__categories" data-categories aria-label="Material category"></div></aside><div class="ew-t17-ui__library-results"><div class="ew-t17-ui__library-note">Use − / + to choose the size, then tap the card to add that Variant. Filters never alter the bracelet already on the tray.</div><div class="ew-t17-ui__grid" data-grid></div></div></div>
    </section>
  </div>
  <dialog class="ew-t17-ui__dialog" data-dialog="wrist"><form method="dialog"><button class="ew-t17-ui__close" value="cancel" aria-label="Close">×</button><span class="ew-t17-ui__eyebrow">WRIST SETTING</span><h2>Your wrist fit</h2><label>Wrist circumference<input type="number" min="10" max="30" step="0.1" value="16" data-wrist-input> cm</label><fieldset><legend>Fit preference</legend><label><input type="radio" name="fit" value="snug"> Snug</label><label><input type="radio" name="fit" value="regular" checked> Regular</label><label><input type="radio" name="fit" value="loose"> Loose</label></fieldset><button class="is-primary" value="confirm" data-action="apply-wrist">Apply wrist setting</button></form></dialog>
  <dialog class="ew-t17-ui__dialog ew-t17-ui__material-details" data-dialog="material-details"><form method="dialog"><button class="ew-t17-ui__close" value="cancel" aria-label="Close">×</button><span class="ew-t17-ui__eyebrow">MATERIAL DETAILS</span><h2 data-material-details-name></h2><p data-material-details-meta></p><button value="close">Close</button></form></dialog>
  <dialog class="ew-t17-ui__dialog" data-dialog="finish"><form method="dialog"><button class="ew-t17-ui__close" value="cancel" aria-label="Close">×</button><span class="ew-t17-ui__eyebrow">DESIGN REVIEW</span><h2>Your bracelet</h2><div data-summary></div><button class="is-primary" type="button" data-action="cart">Add to cart</button></form></dialog>
</section>
